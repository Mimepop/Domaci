package pokemon;

public interface Attackable {


    public String attack();

    public String defend();

    public String wins();

    public String loses();
}
